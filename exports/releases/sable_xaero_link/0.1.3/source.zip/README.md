# Sable-Xaero-Link

独立 NeoForge 1.21.1 模组：服务端采集 Sable 物理结构目录，客户端可选地在 Xaero 世界地图上显示。

## 当前状态

**0.1.3 — 主要功能已完成，等待真实客户端/服务端联调。**

## 已实现

### 服务端

- 已加载 Sable 结构扫描
  - UUID
  - 名称
  - 维度
  - `logicalPose()` 世界投影坐标
- 未加载 `.slvlr` 结构扫描
  - 复用 Sable `SubLevelStorage` / `SubLevelData`
  - 不加载结构本体
- Shtreimel owner 读取
  - `user_data.shtreimel.owner`
  - `user_data.shtreimel.ownerName`
  - 缺失时显示未知
- 快照与增量同步
  - 仅 OP（权限等级 2）
  - 移动结构约 4 Hz
  - 静止结构约每 10 秒刷新
  - 删除/卸载通过 removed UUID 通知
- 级联删除
  - 通过 Sable `SubLevelHelper.getConnectedChain` 收集绳索/约束连接的子结构
  - 删除主结构时统一移除整条连接链
  - 对已加载结构消失仍会重发完整目录，清掉可能残留的未加载标记
  - 未加载子结构如果仍存在于 `.slvlr`，完整扫描会重新列出，需单独清理
- 操作
  - 已加载结构传送
  - 未加载结构传送到保存坐标
  - 删除已加载结构，并统一删除同一连接链
  - 批量删除
  - 未加载结构逻辑删除
  - 删除前复制 `.slvlr` 到 `sable-xaero-link-archive`
  - 尝试通过 `SubLevelStorageFile.clear` 回收 sector
  - sector 回收失败只记日志，逻辑删除仍有效
  - 载具包裹放置：记录最近右键，新增 owner 为空的结构按距离/时间自动补 owner
- 命令
  ```text
  /sablexaerolink snapshot
  /sablexaerolink on
  /sablexaerolink off
  /sablexaerolink list
  /sablexaerolink diagnose
  /sablexaerolink archives
  /sablexaerolink tp <uuid>
  /sablexaerolink delete <uuid...>
  ```

### 客户端

- Xaero 世界地图菱形叠加层
  - 已加载：青色
  - 未加载：灰色
  - 冻结：蓝色
  - 菱形加大并带深色外框，悬停范围同步扩大
  - 悬停：黄色 + owner · 名称
- 世界地图右侧 `S` 按钮
  - 打开配置界面
  - 第一项：显示物理结构叠加层 开/关
  - 开关保存到 `config/sable_xaero_link-client.properties`
  - 结构列表每秒刷新，保留选中项
  - 连接组显示为“连接组 … · N 个结构”分组标题
  - 列表项右键勾选，支持“批量删除选中”
  - “选中整组”按 chainId 勾选整条连接链
- 结构列表按钮
  - 传送
  - 创建 Xaero 路径点
  - 共享位置
  - 地图居中
  - 删除（二次确认）
  - 批量删除 / 选中整组
- 右键菜单
  - 传送到结构
  - 冻结/解冻物理（Shtreimel）
  - 创建 Xaero 路径点
  - 共享位置
  - 工具枪预览此结构
  - 删除（二次确认）

### 可选联动

- Xaero Minimap：路径点/共享
- create_aeronautics_toolgun：工具枪预览桥接

## 依赖

服务端：

- Sable 2.0.6
- Shtreimel 0.7.0（owner 来源）

客户端可选：

- Xaero's World Map 1.47.0
- Xaero's Minimap 26.6.0
- create_aeronautics_toolgun 0.3.9

## 构建

```powershell
cd E:\Users\36389\Desktop\Sable-Xaero-Link
$env:JAVA_HOME='C:\Program Files\Java\jdk-21.0.10'
.\gradlew.bat clean build
.\gradlew.bat test
```

协议编解码和增量缓存的 JUnit 测试已通过。

产物：

```text
build\libs\sable_xaero_link-0.1.3.jar
SHA256 A5C6AB7C1DC473A37093FF043D9DB0FCA0F4E1A02902B3FA592698DE85C4CAA6

版本留痕目录：`exports/releases/sable_xaero_link/0.1.3/`
```

## 尚未完成

- 工具枪预览真实联调
- 载具包裹 owner 补记真实联调（当前是通用右键距离/时间启发式，未针对 HNG 具体物品验证）
- 真实客户端/服务端联调
- 当前环境无法从 `maven.neoforged.net` 下载 `DevLaunch`

## 风险

- 未加载结构删除前会复制区域文件到 `sable-xaero-link-archive`
- 备份失败时拒绝删除，不会“先删后备份”
- 未加载结构 sector 回收通过 Sable 内部 `clear` accessor 实现，必须在测试存档验证
- 连接链分组/批量删除依赖 Sable `getConnectedChain`
- 冻结依赖 Shtreimel `FrozenSubLevels`
- 不修改现有 core、Sable、Shtreimel、Xaero 或存档
