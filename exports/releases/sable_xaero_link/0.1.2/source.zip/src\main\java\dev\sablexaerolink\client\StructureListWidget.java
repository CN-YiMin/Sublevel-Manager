package dev.sablexaerolink.client;

import dev.sablexaerolink.network.StructureEntry;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.ObjectSelectionList;
import net.minecraft.network.chat.Component;

/** Small scrollable list; rows are loaded from the same cache as the Xaero overlay. */
public final class StructureListWidget extends ObjectSelectionList<StructureListWidget.Row> {

    public StructureListWidget(final Minecraft minecraft, final int width, final int height, final int y, final int itemHeight) {
        super(minecraft, width, height, y, itemHeight);
        for (final StructureEntry entry : ClientStructureCache.entries()) {
            addEntry(new Row(entry));
        }
    }

    @Override
    public int getRowWidth() {
        return 280;
    }

    @Override
    protected int getScrollbarPosition() {
        return getX() + getWidth() - 6;
    }

    public StructureEntry selectedEntry() {
        final Row row = getSelected();
        return row == null ? null : row.entry();
    }

    public void reload() {
        final StructureEntry selected = selectedEntry();
        clearEntries();
        for (final StructureEntry entry : ClientStructureCache.entries()) {
            final Row row = new Row(entry);
            addEntry(row);
            if (selected != null && selected.id().equals(entry.id())) {
                setSelected(row);
            }
        }
    }

    public static final class Row extends ObjectSelectionList.Entry<Row> {

        private final StructureEntry entry;

        Row(final StructureEntry entry) {
            this.entry = entry;
        }

        StructureEntry entry() {
            return entry;
        }

        @Override
        public void render(
                final GuiGraphics graphics,
                final int index,
                final int top,
                final int left,
                final int width,
                final int height,
                final int mouseX,
                final int mouseY,
                final boolean hovering,
                final float partialTick) {
            final Minecraft minecraft = Minecraft.getInstance();
            final String marker = entry.loaded() ? "[L] " : "[U] ";
            final String name = entry.name().isBlank()
                    ? entry.id().toString().substring(0, 8)
                    : entry.name();
            final String text = marker + entry.ownerLabel() + " · " + name;
            graphics.drawString(minecraft.font, text, left + 4, top + 4, 0xFFFFFFFF, false);
            graphics.drawString(minecraft.font,
                    String.format("%.0f %.0f %.0f", entry.x(), entry.y(), entry.z()),
                    left + 4, top + 16, 0xFF8A8A8A, false);
        }

        @Override
        public Component getNarration() {
            return Component.literal(entry.ownerLabel() + " · " + entry.name());
        }
    }
}
