package dev.sablexaerolink.client;

import dev.sablexaerolink.network.StructureDeltaPayload;
import dev.sablexaerolink.network.StructureEntry;
import dev.sablexaerolink.network.StructureSnapshotPayload;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/** Last directory received from the server. Client-only content, no Xaero classes here. */
public final class ClientStructureCache {

    private static volatile List<StructureEntry> entries = List.of();
    private static volatile long version;

    private ClientStructureCache() {
    }

    public static long version() {
        return version;
    }

    public static void accept(final StructureSnapshotPayload payload) {
        if (payload.full()) {
            entries = List.copyOf(payload.entries());
            version++;
            return;
        }
        // Periodic packets contain loaded structures only. Keep the unloaded entries
        // from the last full snapshot, otherwise the grey markers would vanish every second.
        final Map<UUID, StructureEntry> merged = new LinkedHashMap<>();
        for (final StructureEntry entry : entries) {
            if (!entry.loaded()) {
                merged.put(entry.id(), entry);
            }
        }
        for (final StructureEntry entry : payload.entries()) {
            merged.put(entry.id(), entry);
        }
        entries = List.copyOf(merged.values());
        version++;
    }

    public static List<StructureEntry> entries() {
        return entries;
    }

    public static void applyDelta(final StructureDeltaPayload payload) {
        final Map<UUID, StructureEntry> merged = new LinkedHashMap<>();
        for (final StructureEntry entry : entries) {
            merged.put(entry.id(), entry);
        }
        for (final UUID removed : payload.removed()) {
            merged.remove(removed);
        }
        for (final StructureEntry entry : payload.upserts()) {
            merged.put(entry.id(), entry);
        }
        entries = List.copyOf(merged.values());
        version++;
    }

    public static void clear() {
        entries = List.of();
        version++;
    }

    /** Signals a display-state change without discarding the last snapshot. */
    public static void touch() {
        version++;
    }
}
