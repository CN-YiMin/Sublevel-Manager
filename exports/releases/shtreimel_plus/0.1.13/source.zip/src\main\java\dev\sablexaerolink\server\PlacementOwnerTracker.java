package dev.sablexaerolink.server;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import dev.ryanhcode.sable.api.sublevel.ServerSubLevelContainer;
import dev.ryanhcode.sable.api.sublevel.SubLevelContainer;
import dev.ryanhcode.sable.sublevel.ServerSubLevel;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/**
 * Best-effort owner assignment for placement items that create Sable sub-levels without
 * setting Shtreimel's owner (for example some package/vehicle items).
 *
 * <p>It records a recent right-click, then assigns the first newly loaded, still ownerless
 * sub-levels near that click to the clicking player. Existing owners are never overwritten.
 */
public final class PlacementOwnerTracker {

    private static final long MAX_AGE_MS = 10_000L;
    private static final double MAX_DISTANCE = 24.0;
    private static final int SCAN_TICKS = 5;
    private static final Map<UUID, Pending> PENDING = new HashMap<>();
    private static final Set<UUID> SEEN = new HashSet<>();
    private static boolean initialized;
    private static int scanCooldown;

    private PlacementOwnerTracker() {
    }

    public static void reset() {
        PENDING.clear();
        SEEN.clear();
        initialized = false;
        scanCooldown = 0;
    }

    /**
     * One snapshot at server start. No per-tick sub-level traversal is performed after this.
     */
    public static void onServerStarted(final MinecraftServer server) {
        reset();
        for (final ServerLevel level : server.getAllLevels()) {
            final ServerSubLevelContainer container = SubLevelContainer.getContainer(level);
            if (container == null) {
                continue;
            }
            for (final ServerSubLevel sub : container.getAllSubLevels()) {
                SEEN.add(sub.getUniqueId());
            }
        }
        initialized = true;
    }

    public static void onRightClickBlock(final PlayerInteractEvent.RightClickBlock event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            record(player, event.getLevel(), Vec3.atCenterOf(event.getPos()));
        }
    }

    public static void onRightClickItem(final PlayerInteractEvent.RightClickItem event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            record(player, event.getLevel(), player.position());
        }
    }

    private static void record(final ServerPlayer player, final net.minecraft.world.level.Level level, final Vec3 pos) {
        PENDING.put(player.getUUID(), new Pending(
                player.getUUID(), player.getGameProfile().getName(),
                level.dimension(), pos, System.currentTimeMillis()));
        scanCooldown = 0;
    }

    /**
     * Only scans after a placement click. When no pending click exists this is O(1) and
     * never touches the sub-level container.
     */
    public static void tick(final MinecraftServer server) {
        if (!initialized || PENDING.isEmpty()) {
            return;
        }
        if (++scanCooldown < SCAN_TICKS) {
            return;
        }
        scanCooldown = 0;

        final long now = System.currentTimeMillis();
        PENDING.entrySet().removeIf(entry -> now - entry.getValue().time() > MAX_AGE_MS);
        if (PENDING.isEmpty()) {
            return;
        }

        final Set<UUID> current = new HashSet<>();
        for (final ServerLevel level : server.getAllLevels()) {
            final ServerSubLevelContainer container = SubLevelContainer.getContainer(level);
            if (container == null) {
                continue;
            }
            for (final ServerSubLevel sub : container.getAllSubLevels()) {
                current.add(sub.getUniqueId());
                if (SEEN.contains(sub.getUniqueId())) {
                    continue;
                }
                assignIfPossible(level, sub, now);
            }
        }
        SEEN.addAll(current);
    }

    private static void assignIfPossible(final ServerLevel level, final ServerSubLevel sub, final long now) {
        final CompoundTag userData = sub.getUserDataTag();
        if (userData != null
                && userData.contains("shtreimel", CompoundTag.TAG_COMPOUND)
                && userData.getCompound("shtreimel").contains("owner")) {
            return;
        }
        final var pos = sub.logicalPose().position();
        Pending best = null;
        for (final Pending pending : PENDING.values()) {
            if (!pending.dimension().equals(level.dimension())) {
                continue;
            }
            if (now - pending.time() > MAX_AGE_MS) {
                continue;
            }
            if (pending.pos().distanceToSqr(pos.x, pos.y, pos.z) > MAX_DISTANCE * MAX_DISTANCE) {
                continue;
            }
            if (best == null || pending.time() > best.time()) {
                best = pending;
            }
        }
        if (best == null) {
            return;
        }
        final CompoundTag user = userData == null ? new CompoundTag() : userData.copy();
        final CompoundTag owner = user.contains("shtreimel", CompoundTag.TAG_COMPOUND)
                ? user.getCompound("shtreimel")
                : new CompoundTag();
        owner.putUUID("owner", best.player());
        owner.putString("ownerName", best.name());
        owner.putString("how", "placement");
        owner.putLong("since", now);
        user.put("shtreimel", owner);
        sub.setUserDataTag(user);
        dev.sablexaerolink.SableXaeroLink.LOGGER.info(
                "[shtreimel-plus] assigned placement owner {} to {}",
                best.name(), sub.getUniqueId());
    }

    private record Pending(UUID player, String name,
                           net.minecraft.resources.ResourceKey<net.minecraft.world.level.Level> dimension,
                           Vec3 pos, long time) {
    }
}
