package dev.sablexaerolink.server;

import dev.sablexaerolink.SableXaeroLink;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.server.ServerStartedEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

@EventBusSubscriber(modid = SableXaeroLink.MOD_ID, bus = EventBusSubscriber.Bus.GAME)
public final class ServerEvents {

    private ServerEvents() {
    }

    @SubscribeEvent
    public static void onServerTick(final ServerTickEvent.Post event) {
        StructureDirectory.tick(event.getServer());
        PlacementOwnerTracker.tick(event.getServer());
    }

    @SubscribeEvent
    public static void onRightClickBlock(final PlayerInteractEvent.RightClickBlock event) {
        PlacementOwnerTracker.onRightClickBlock(event);
    }

    @SubscribeEvent
    public static void onRightClickItem(final PlayerInteractEvent.RightClickItem event) {
        PlacementOwnerTracker.onRightClickItem(event);
    }

    @SubscribeEvent
    public static void onServerStarted(final ServerStartedEvent event) {
        PlacementOwnerTracker.onServerStarted(event.getServer());
    }

    @SubscribeEvent
    public static void onServerStopped(final ServerStoppedEvent event) {
        PlacementOwnerTracker.reset();
    }

    @SubscribeEvent
    public static void onLogout(final PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof net.minecraft.server.level.ServerPlayer player) {
            StructureDirectory.remove(player);
        }
    }
}
