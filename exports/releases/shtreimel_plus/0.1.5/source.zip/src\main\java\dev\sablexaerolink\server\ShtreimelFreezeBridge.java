package dev.sablexaerolink.server;

import dev.ryanhcode.sable.sublevel.ServerSubLevel;
import java.util.UUID;
import net.neoforged.fml.ModList;

/**
 * Optional Shtreimel freeze integration. The class is only touched after ModList says
 * Shtreimel is present, so the mod still works when Shtreimel is absent.
 */
public final class ShtreimelFreezeBridge {

    private ShtreimelFreezeBridge() {
    }

    public static boolean available() {
        return ModList.get().isLoaded("shtreimel");
    }

    public static boolean isFrozen(final UUID id) {
        if (!available()) {
            return false;
        }
        return dev.playcdu.shtreimel.freeze.FrozenSubLevels.isFrozen(id);
    }

    /** @return true when the structure is frozen after the call. */
    public static boolean toggle(final ServerSubLevel sub, final net.minecraft.resources.ResourceKey<net.minecraft.world.level.Level> dimension) {
        if (!available()) {
            return false;
        }
        if (dev.playcdu.shtreimel.freeze.FrozenSubLevels.isFrozen(sub.getUniqueId())) {
            dev.playcdu.shtreimel.freeze.FrozenSubLevels.unfreeze(sub.getUniqueId());
            return false;
        }
        dev.playcdu.shtreimel.freeze.FrozenSubLevels.freeze(sub, dimension);
        return dev.playcdu.shtreimel.freeze.FrozenSubLevels.isFrozen(sub.getUniqueId());
    }
}
