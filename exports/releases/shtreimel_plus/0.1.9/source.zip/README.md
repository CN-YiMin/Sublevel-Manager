# Shtreimel Plus

独立 NeoForge 1.21.1 模组：服务端采集 Sable 物理结构目录，客户端可选地在 Xaero 世界地图上显示。

## 当前状态

**0.1.9 — 主要功能已完成，等待真实客户端/服务端联调。**

## 已实现

### 服务端

- 已加载 Sable 结构扫描
  - UUID
  - 名称
  - 维度
  - `logicalPose()` 世界投影坐标
- 未加载 `.slvlr` 结构扫描
  - 复用 Sable `SubLevelStorage` / `SubLevelData`
  - 不加载结构本体
- Shtreimel owner 读取
  - `user_data.shtreimel.owner`
  - `user_data.shtreimel.ownerName`
  - 缺失时显示未知
- 快照与增量同步
  - 所有玩家都可订阅查看目录
  - 传送/冻结/删除仍要求 OP（权限等级 2）
  - 非 OP 客户端只显示只读、路径点、共享、工具枪预览、地图居中
  - 移动结构约 4 Hz
  - 静止结构约每 10 秒刷新
  - 删除/卸载通过 removed UUID 通知
  - 删除后立即发 removed UUID，再发权威完整快照
- 级联删除
  - 通过 Sable `SubLevelHelper.getConnectedChain` 收集绳索/约束连接的子结构
  - 删除主结构时统一移除整条连接链
  - 对已加载结构消失仍会重发完整目录，清掉可能残留的未加载标记
  - 未加载子结构如果仍存在于 `.slvlr`，完整扫描会重新列出，需单独清理
- 操作
  - 已加载结构传送
  - 未加载结构传送到保存坐标
  - 删除已加载结构，并统一删除同一连接链
  - 批量删除
  - 未加载结构逻辑删除
  - 删除前复制 `.slvlr` 到 `shtreimel-plus-archive`
  - 尝试通过 `SubLevelStorageFile.clear` 回收 sector
  - sector 回收失败只记日志，逻辑删除仍有效
  - 载具包裹放置：记录最近右键，新增 owner 为空的结构按距离/时间自动补 owner
- 命令
  ```text
  /shtreimelplus snapshot
  /shtreimelplus on
  /shtreimelplus off
  /shtreimelplus list
  /shtreimelplus diagnose
  /shtreimelplus archives
  /shtreimelplus tp <uuid>
  /shtreimelplus delete <uuid...>
  ```

### 客户端

- Xaero 世界地图菱形叠加层
  - 已加载：青色
  - 未加载：灰色
  - 冻结：蓝色
  - 菱形加大并带深色外框，悬停范围同步扩大
  - 悬停：黄色 + owner · 名称
- 世界地图右侧 `S` 按钮
  - 打开配置界面
  - 第一项：显示物理结构叠加层 开/关
  - 开关保存到 `config/shtreimel_plus-client.properties`
  - 结构列表收到新快照/增量后立即刷新，并每秒兜底刷新
  - 连接组显示为“连接组 … · N 个结构”分组标题
  - 普通点击只选中当前条目，Ctrl 点击可多选
  - 点击连接组标题一次性选中整组
- 结构列表按钮
  - 传送
  - 创建 Xaero 路径点
  - 共享位置
  - 地图居中
  - 删除选中（单个二次确认，多个进入批量确认）
- 右键菜单
  - 传送到结构
  - 冻结/解冻物理（Shtreimel）
  - 创建 Xaero 路径点
  - 共享位置
  - 工具枪预览此结构
  - 删除（二次确认）

### 可选联动

- Xaero Minimap：路径点/共享
- create_aeronautics_toolgun：工具枪预览桥接

## 依赖

服务端：

- Sable 2.0.6
- Shtreimel 0.7.0（owner 来源）

客户端可选：

- Xaero's World Map 1.47.0
- Xaero's Minimap 26.6.0
- create_aeronautics_toolgun 0.3.9

## 构建

```powershell
cd E:\Users\36389\Desktop\Shtreimel-Plus
$env:JAVA_HOME='C:\Program Files\Java\jdk-21.0.10'
.\gradlew.bat clean build
.\gradlew.bat test
```

协议编解码和增量缓存的 JUnit 测试已通过。

产物：

```text
build\libs\shtreimel_plus-0.1.9.jar
SHA256 9AD633E4954745F55A83E55A66BC8652D267E4CC9E11B0E6B031EC6E611972D3

版本留痕目录：`exports/releases/shtreimel_plus/0.1.9/`
```

## 尚未完成

- 工具枪预览真实联调
- 载具包裹 owner 补记真实联调（当前是通用右键距离/时间启发式，未针对 HNG 具体物品验证）
- 真实客户端/服务端联调
- 当前环境无法从 `maven.neoforged.net` 下载 `DevLaunch`

## 风险

- 未加载结构删除前会复制区域文件到 `shtreimel-plus-archive`
- 备份失败时拒绝删除，不会“先删后备份”
- 未加载结构 sector 回收通过 Sable 内部 `clear` accessor 实现，必须在测试存档验证
- 连接链分组/批量删除依赖 Sable `getConnectedChain`
- 冻结依赖 Shtreimel `FrozenSubLevels`
- 不修改现有 core、Sable、Shtreimel、Xaero 或存档
